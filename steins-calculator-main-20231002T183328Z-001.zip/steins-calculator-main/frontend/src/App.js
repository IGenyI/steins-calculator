import Login from "./components/Login";
import Register from "./components/Register";
function App() {
  return (
    <div>
      <Register/>
    </div>
  );
}

export default App;
